import 'package:patrol/patrol.dart';
import 'package:patrol_practice/main.dart';

const patrolConfig = PatrolTesterConfig();

// TODO: Replace with values specific to your app.
const nativeAutomatorConfig = NativeAutomatorConfig(
  packageName: 'com.example.patrol_practice',//patrol-0.10.7\android
  bundleId: 'com.example.patrol_practice',
);
//com/example/patrol_practice
//com.example.patrol_practice
//C:\flutter\.pub-cache\hosted\pub.dartlang.org\patrol-0.10.7\android
//C:\flutter\.pub-cache\hosted\pub.dartlang.org\patrol-0.10.7\ios